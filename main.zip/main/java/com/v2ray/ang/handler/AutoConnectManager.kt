package com.v2ray.ang.handler

import com.v2ray.ang.AppConfig
import com.v2ray.ang.dto.entities.SubscriptionCache
import com.v2ray.ang.dto.entities.SubscriptionItem
import com.v2ray.ang.util.LogUtil

object AutoConnectManager {

    
    fun ensureSubscription(): String {
        MmkvManager.decodeSubscriptions()
            .firstOrNull { it.subscription.url == AppConfig.HAMEDVPNS_SUB_URL }
            ?.let { return it.guid }

        val subItem = SubscriptionItem(
            remarks = AppConfig.HAMEDVPNS_SUB_REMARKS,
            url = AppConfig.HAMEDVPNS_SUB_URL,
            enabled = true,
            autoUpdate = false
        )
        MmkvManager.encodeSubscription("", subItem)

        return MmkvManager.decodeSubscriptions()
            .first { it.subscription.url == AppConfig.HAMEDVPNS_SUB_URL }
            .guid
    }

    
    fun refreshBatch(subId: String): List<String> {
        return try {
            val subItem = MmkvManager.decodeSubscription(subId) ?: return emptyList()
            val result = AngConfigManager.updateConfigViaSub(SubscriptionCache(subId, subItem))
            if (result.configCount <= 0) {
                LogUtil.w(AppConfig.TAG, "hamedvpns: subscription fetch returned no usable configs")
            }

            val fullList = MmkvManager.decodeServerList(subId)
            val batch = fullList.take(AppConfig.HAMEDVPNS_TEST_BATCH_SIZE)

            fullList.drop(AppConfig.HAMEDVPNS_TEST_BATCH_SIZE).forEach { MmkvManager.removeServer(it) }
            if (batch.isNotEmpty()) {
                MmkvManager.encodeServerList(batch.toMutableList(), subId)
            }
            MmkvManager.clearAllTestDelayResults(batch)

            batch
        } catch (e: Exception) {
            LogUtil.e(AppConfig.TAG, "hamedvpns: failed to refresh batch", e)
            emptyList()
        }
    }
}

