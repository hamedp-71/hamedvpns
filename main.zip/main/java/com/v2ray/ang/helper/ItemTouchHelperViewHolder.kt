
package com.v2ray.ang.helper

import androidx.recyclerview.widget.ItemTouchHelper

interface ItemTouchHelperViewHolder {
    
    fun onItemSelected()

    
    fun onItemClear()
}

